using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;
    private Animator anim;

    void Start()
    {
        // Karakterin üzerindeki Animator bileşenini otomatik bulur
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        Vector3 moveDir = Vector3.zero;

        if (Keyboard.current != null)
        {
            if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
                moveDir += Vector3.up;
            if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
                moveDir += Vector3.down;
            if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed)
                moveDir += Vector3.left;
            if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed)
                moveDir += Vector3.right;
        }

        transform.Translate(moveDir * speed * Time.deltaTime);

        // Hareket varsa animasyonu oynat (1), duruyorsa dondur (0)
        if (anim != null)
        {
            if (moveDir != Vector3.zero)
            {
                anim.speed = 1f;
            }
            else
            {
                anim.speed = 0f;
            }
        }
    }
}