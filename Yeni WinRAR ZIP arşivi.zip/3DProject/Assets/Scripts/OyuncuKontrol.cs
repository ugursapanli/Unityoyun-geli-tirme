using UnityEngine;
using UnityEngine.InputSystem; // Yeni Girdi Sistemi

public class OyuncuKontrol : MonoBehaviour
{
    public float hiz = 5f;
    public float fareHassasiyeti = 0.1f; // Yeni sistemde fare çok hızlı döner, o yüzden kıstık
    public Transform kamera;
    
    float xRotasyon = 0f;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // 1. FARE İLE ETRAFA BAKMA
        if (Mouse.current != null)
        {
            // Yeni sistemde farenin hareket miktarını böyle okuyoruz
            Vector2 fare = Mouse.current.delta.ReadValue() * fareHassasiyeti;
            
            xRotasyon -= fare.y;
            xRotasyon = Mathf.Clamp(xRotasyon, -90f, 90f);

            kamera.localRotation = Quaternion.Euler(xRotasyon, 0f, 0f); 
            transform.Rotate(Vector3.up * fare.x);
        }

        // 2. KLAVYE İLE YÜRÜME (WASD)
        if (Keyboard.current != null)
        {
            float yatay = 0f;
            float dikey = 0f;

            if (Keyboard.current.wKey.isPressed) dikey += 1f;
            if (Keyboard.current.sKey.isPressed) dikey -= 1f;
            if (Keyboard.current.dKey.isPressed) yatay += 1f;
            if (Keyboard.current.aKey.isPressed) yatay -= 1f;

            Vector3 hareket = transform.right * yatay + transform.forward * dikey;
            transform.position += hareket * hiz * Time.deltaTime;
        }
    }
}