using UnityEngine;

public class SimpleRaycast : MonoBehaviour
{
    public float menzil = 10f;
    private GameObject sonBaktigimObje; // Konsolun kilitlenmesini önlemek için tuttuğumuz değişken

    void Update()
    {
        // 1. Kameradan ileriye doğru bir ışın oluşturuyoruz
        Ray ray = new Ray(transform.position, transform.forward);
        RaycastHit hit;

        // 2. Işın bir objeye çarparsa
        if (Physics.Raycast(ray, out hit, menzil))
        {
            // Baktığımız obje bir önceki baktığımız objeden farklıysa konsola yazdır
            if (hit.collider.gameObject != sonBaktigimObje)
            {
                sonBaktigimObje = hit.collider.gameObject;
                Debug.Log("Baktığın Obje: " + sonBaktigimObje.name);
            }

            // Sahne ekranında ışını yeşil göster
            Debug.DrawRay(ray.origin, ray.direction * hit.distance, Color.green);
        }
        else
        {
            // Hiçbir şeye bakmıyorsak hafızadaki objeyi sıfırla
            sonBaktigimObje = null;

            // Sahne ekranında ışını kırmızı göster
            Debug.DrawRay(ray.origin, ray.direction * menzil, Color.red);
        }
    }
}